﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IIWGTI
{
    enum SubjectNames
    {
        CompSci,
        English,
        Math,
        PE
    }
}
