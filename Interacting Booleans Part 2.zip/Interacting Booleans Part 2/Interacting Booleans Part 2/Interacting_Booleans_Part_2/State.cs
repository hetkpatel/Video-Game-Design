﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interacting_Booleans_Part_2
{
    enum State
    {
        Standing,
        Jumping,
        Ducking,
        Diving
    }
}
